export const url = {
    api: "http://ec2-13-127-78-120.ap-south-1.compute.amazonaws.com:"
  };
  