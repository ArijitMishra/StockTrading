export class ContactModel{

    _id?:String;
    Name!: String;
    Gender!: String;
    Contact!: Number;
	Dob!:String;
	Account!:String;
	Address!:String;
	Email!:String;
	Password!:String;
	// Salt_key!:String;
}